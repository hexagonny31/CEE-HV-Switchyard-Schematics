-- Klondike solitaire for ComputerCraft: Cursed Earth.

local SUITS = { "S", "H", "D", "C" }
local CARD_WIDTH = 6
local TABLEAU_Y = 5
local C = colours

local stock, waste, foundations, tableau
local selection
local focusColumn, focusCard = 1, 1
local running = true
local status = "Welcome! Draw a card or select a tableau card."

local function rankName(rank)
  if rank == 1 then return "A" end
  if rank == 11 then return "J" end
  if rank == 12 then return "Q" end
  if rank == 13 then return "K" end
  return tostring(rank)
end

local function isRed(card)
  return card.suit == "H" or card.suit == "D"
end

local function newGame()
  local deck = {}
  for _, suit in ipairs(SUITS) do
    for rank = 1, 13 do
      deck[#deck + 1] = { rank = rank, suit = suit, faceUp = false }
    end
  end

  local seed = os.epoch and os.epoch("utc") or math.floor(os.clock() * 1000000)
  math.randomseed(seed % 2147483647)
  for i = #deck, 2, -1 do
    local j = math.random(i)
    deck[i], deck[j] = deck[j], deck[i]
  end

  stock, waste = {}, {}
  foundations = { {}, {}, {}, {} }
  tableau = { {}, {}, {}, {}, {}, {}, {} }
  selection = nil
  focusColumn, focusCard = 1, 1

  for column = 1, 7 do
    for row = 1, column do
      local card = table.remove(deck)
      card.faceUp = row == column
      tableau[column][#tableau[column] + 1] = card
    end
  end
  for i = 1, #deck do stock[#stock + 1] = deck[i] end
  status = "New game. Build down in alternating colours; build foundations up by suit."
end

local function drawStock()
  selection = nil
  if #stock > 0 then
    local card = table.remove(stock)
    card.faceUp = true
    waste[#waste + 1] = card
    status = "Drew " .. rankName(card.rank) .. card.suit .. "."
  elseif #waste > 0 then
    for i = #waste, 1, -1 do
      local card = table.remove(waste)
      card.faceUp = false
      stock[#stock + 1] = card
    end
    status = "Recycled the waste pile."
  else
    status = "There are no cards left in the stock."
  end
end

local function selectCard(source, pile, index)
  local card
  if source == "tableau" then
    local cards = tableau[pile]
    card = cards and cards[index]
    if not card or not card.faceUp then
      status = "Select a face-up tableau card."
      return false
    end
  elseif source == "waste" then
    if pile ~= 1 then return false end
    card = waste[#waste]
  elseif source == "foundation" then
    local cards = foundations[pile]
    card = cards and cards[#cards]
  end
  if not card then
    status = "That pile has no card to select."
    return false
  end
  selection = { source = source, pile = pile, index = source == "tableau" and index or nil }
  status = "Selected " .. rankName(card.rank) .. card.suit .. ". Choose a destination."
  return true
end

local function selectedCard()
  if not selection then return nil end
  if selection.source == "tableau" then
    return tableau[selection.pile][selection.index]
  elseif selection.source == "waste" then
    return waste[#waste]
  end
  local cards = foundations[selection.pile]
  return cards[#cards]
end

local function removeSelection()
  local moved
  if selection.source == "tableau" then
    local cards = tableau[selection.pile]
    moved = {}
    while #cards >= selection.index do
      moved[#moved + 1] = table.remove(cards, selection.index)
    end
    if #cards > 0 and not cards[#cards].faceUp then
      cards[#cards].faceUp = true
    end
  elseif selection.source == "waste" then
    moved = { table.remove(waste) }
  else
    moved = { table.remove(foundations[selection.pile]) }
  end
  selection = nil
  return moved
end

local function tryMoveToTableau(destination)
  if not selection then return false end
  if selection.source == "tableau" and selection.pile == destination then
    return false
  end

  local card = selectedCard()
  if not card then return false end
  local target = tableau[destination]
  local top = target[#target]
  local legal = top and (top.faceUp and isRed(top) ~= isRed(card) and top.rank == card.rank + 1)
    or (not top and card.rank == 13)
  if not legal then
    status = "Invalid move: place a King on an empty column, or alternate colours downward."
    return false
  end

  local moved = removeSelection()
  for i = 1, #moved do target[#target + 1] = moved[i] end
  focusColumn, focusCard = destination, #target
  status = "Moved " .. rankName(card.rank) .. card.suit .. " to column " .. destination .. "."
  return true
end

local function tryMoveToFoundation(destination)
  if not selection then return false end
  local card = selectedCard()
  if not card then return false end
  if selection.source == "tableau" and selection.index ~= #tableau[selection.pile] then
    status = "Only a single card can be moved to a foundation."
    return false
  end
  if selection.source == "foundation" then
    status = "That card is already in a foundation."
    return false
  end
  if SUITS[destination] ~= card.suit then
    status = "Foundations must match the card's suit."
    return false
  end

  local target = foundations[destination]
  local top = target[#target]
  if (top and card.rank ~= top.rank + 1) or (not top and card.rank ~= 1) then
    status = "Foundations start with an Ace and build up by suit."
    return false
  end
  removeSelection()
  target[#target + 1] = card
  status = "Moved " .. rankName(card.rank) .. card.suit .. " to its foundation."

  local won = true
  for i = 1, #foundations do
    if #foundations[i] ~= 13 then won = false break end
  end
  if won then status = "You win! Press N or click NEW to play again." end
  return true
end

local function autoFoundation()
  if selection then
    local card = selectedCard()
    if card then
      for i, suit in ipairs(SUITS) do
        if suit == card.suit then
          tryMoveToFoundation(i)
          return
        end
      end
    end
    return
  end
  if #waste > 0 and selectCard("waste", 1) then
    local card = selectedCard()
    for i, suit in ipairs(SUITS) do
      if suit == card.suit then
        if tryMoveToFoundation(i) then return end
        break
      end
    end
    selection = nil
  end
  for column = 1, 7 do
    local cards = tableau[column]
    if #cards > 0 and cards[#cards].faceUp and selectCard("tableau", column, #cards) then
      local card = selectedCard()
      for i, suit in ipairs(SUITS) do
        if suit == card.suit then
          if tryMoveToFoundation(i) then return end
          break
        end
      end
      selection = nil
    end
  end
  status = "No exposed card can move to a foundation."
end

local function writeAt(x, y, text, foreground, background)
  local width, height = term.getSize()
  if y < 1 or y > height or x > width then return end
  if x < 1 then
    text = text:sub(2 - x)
    x = 1
  end
  text = text:sub(1, width - x + 1)
  term.setCursorPos(x, y)
  term.setTextColor(foreground)
  term.setBackgroundColor(background)
  term.write(text)
end

local function cardText(card)
  local value = rankName(card.rank) .. card.suit
  local inner = CARD_WIDTH - 2
  local left = math.floor((inner - #value) / 2)
  return "[" .. (" "):rep(left) .. value .. (" "):rep(inner - left - #value) .. "]"
end

local function drawCard(x, y, card, hidden, selected)
  if hidden then
    writeAt(x, y, "[####]", C.lightBlue, C.blue)
  elseif not card then
    writeAt(x, y, "[    ]", C.green, C.black)
  elseif selected then
    writeAt(x, y, cardText(card), isRed(card) and C.red or C.black, C.cyan)
  else
    writeAt(x, y, cardText(card), isRed(card) and C.red or C.black, C.white)
  end
end

local function columnStep(width)
  return math.max(1, math.floor((width - CARD_WIDTH) / 6))
end

local function foundationStart(width)
  return math.max(1, width - (4 * CARD_WIDTH + 3) + 1)
end

local function draw()
  local width, height = term.getSize()
  local step = columnStep(width)
  local rows = math.max(1, height - TABLEAU_Y - 1)
  term.setBackgroundColor(C.black)
  term.setTextColor(C.white)
  term.clear()

  writeAt(1, 1, "KLONDIKE", C.lime, C.black)
  writeAt(width - 11, 1, "[NEW]", C.yellow, C.black)
  writeAt(width - 5, 1, "[QUIT]", C.red, C.black)
  writeAt(1, 2, "STOCK", C.lightGrey, C.black)
  writeAt(step + 1, 2, "WASTE", C.lightGrey, C.black)
  local baseX = foundationStart(width)
  writeAt(baseX, 2, "FOUNDATIONS", C.lightGrey, C.black)

  if #stock > 0 then
    drawCard(1, 3, nil, true, false)
  elseif #waste > 0 then
    writeAt(1, 3, "[RCL ]", C.green, C.black)
  else
    drawCard(1, 3, nil, false, false)
  end
  drawCard(step + 1, 3, waste[#waste], false, selection and selection.source == "waste")
  for i = 1, 4 do
    local cards = foundations[i]
    drawCard(baseX + (i - 1) * (CARD_WIDTH + 1), 3, cards[#cards], false,
      selection and selection.source == "foundation" and selection.pile == i)
  end

  for column = 1, 7 do
    local cards = tableau[column]
    local maxStart = math.max(1, #cards - rows + 1)
    local start = math.min(focusCard, maxStart)
    if column ~= focusColumn then start = maxStart end
    local x = 1 + (column - 1) * step
    writeAt(x, 4, tostring(column), column == focusColumn and C.yellow or C.lightGrey, C.black)
    for row = 0, rows - 1 do
      local index = start + row
      if index <= #cards then
        local card = cards[index]
        local chosen = selection and selection.source == "tableau"
          and selection.pile == column and index >= selection.index
        drawCard(x, TABLEAU_Y + row, card, not card.faceUp, chosen)
      elseif #cards == 0 and row == 0 then
        drawCard(x, TABLEAU_Y, nil, false, false)
      end
    end
    if column == focusColumn then
      local focusY = TABLEAU_Y + focusCard - start
      if focusY >= TABLEAU_Y and focusY < TABLEAU_Y + rows then
        writeAt(math.max(1, x - 1), focusY, ">", C.yellow, C.black)
      end
    end
  end

  if height >= 2 then
    writeAt(1, height - 1, status, C.white, C.black)
    writeAt(1, height, "Click cards or use arrows, 1-7, Enter, D, W, A, N, Q.", C.lightGrey, C.black)
  end
  term.setCursorPos(1, 1)
end

local function clickTableau(x, y)
  local width, height = term.getSize()
  local step = columnStep(width)
  local rows = math.max(1, height - TABLEAU_Y - 1)
  if y < TABLEAU_Y or y >= TABLEAU_Y + rows then return false end

  local column = math.floor((x - 1) / step) + 1
  if column < 1 or column > 7 then return false end
  local cards = tableau[column]
  local maxStart = math.max(1, #cards - rows + 1)
  local start = column == focusColumn and math.min(focusCard, maxStart) or maxStart
  local index = start + y - TABLEAU_Y
  focusColumn = column
  if index <= #cards then
    focusCard = index
    if selection and not (selection.source == "tableau" and selection.pile == column) then
      tryMoveToTableau(column)
      return true
    end
    selectCard("tableau", column, index)
  else
    focusCard = #cards
    if selection then
      tryMoveToTableau(column)
    else
      status = "Select a card first; only a King can fill an empty column."
    end
  end
  return true
end

local function handleClick(button, x, y)
  local width = term.getSize()
  if button == 2 then
    selection = nil
    status = "Selection cleared."
    return
  elseif button ~= 1 then
    return
  end
  if y == 1 and x >= width - 11 and x <= width - 7 then
    newGame()
    return
  elseif y == 1 and x >= width - 5 then
    running = false
    return
  elseif y == 3 then
    local step = columnStep(width)
    if x >= 1 and x <= CARD_WIDTH then
      drawStock()
      return
    elseif x >= step + 1 and x <= step + CARD_WIDTH then
      if #waste > 0 then selectCard("waste", 1) end
      return
    end
    local baseX = foundationStart(width)
    for i = 1, 4 do
      local left = baseX + (i - 1) * (CARD_WIDTH + 1)
      if x >= left and x < left + CARD_WIDTH then
        if selection then
          tryMoveToFoundation(i)
        else
          selectCard("foundation", i)
        end
        return
      end
    end
  end
  clickTableau(x, y)
end

newGame()
while running do
  draw()
  local event, a, b, c = os.pullEvent()
  if event == "mouse_click" then
    handleClick(a, b, c)
  elseif event == "key" then
    if a == keys.escape then
      selection = nil
      status = "Selection cleared."
    elseif a == keys.left then
      focusColumn = math.max(1, focusColumn - 1)
      focusCard = math.min(#tableau[focusColumn], math.max(1, focusCard))
    elseif a == keys.right then
      focusColumn = math.min(7, focusColumn + 1)
      focusCard = math.min(#tableau[focusColumn], math.max(1, focusCard))
    elseif a == keys.up then
      local firstFaceUp = 1
      while firstFaceUp <= #tableau[focusColumn] and not tableau[focusColumn][firstFaceUp].faceUp do
        firstFaceUp = firstFaceUp + 1
      end
      focusCard = math.max(firstFaceUp, focusCard - 1)
    elseif a == keys.down then
      focusCard = math.min(#tableau[focusColumn], focusCard + 1)
    elseif a == keys.enter or a == keys.space then
      if selection then
        tryMoveToTableau(focusColumn)
      elseif #tableau[focusColumn] > 0 then
        selectCard("tableau", focusColumn, focusCard)
      else
        status = "That column is empty."
      end
    elseif a == keys.f1 or a == keys.f2 or a == keys.f3 or a == keys.f4 then
      local foundation = a - keys.f1 + 1
      if selection then
        tryMoveToFoundation(foundation)
      else
        selectCard("foundation", foundation)
      end
    elseif a == keys.d then
      drawStock()
    elseif a == keys.w then
      selectCard("waste", 1)
    elseif a == keys.a then
      autoFoundation()
    elseif a == keys.n then
      newGame()
    elseif a == keys.q then
      running = false
    end
  elseif event == "char" then
    local column = tonumber(a)
    if column and column >= 1 and column <= 7 then
      if selection then
        tryMoveToTableau(column)
      else
        focusColumn = column
        focusCard = #tableau[column]
        if focusCard > 0 then selectCard("tableau", column, focusCard) end
      end
    end
  end
end

term.setBackgroundColor(C.black)
term.setTextColor(C.white)
term.clear()
term.setCursorPos(1, 1)
