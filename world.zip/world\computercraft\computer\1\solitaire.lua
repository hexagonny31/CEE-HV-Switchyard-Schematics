-- Klondike solitaire for ComputerCraft.

local SUITS = { "S", "H", "D", "C" }
local CARD_WIDTH = 6
local TABLEAU_Y = 6
local C = colours

local stock, waste, foundations, tableau
local selection
local focusColumn, focusCard = 1, 1
local tableauTop = { 1, 1, 1, 1, 1, 1, 1 }
local running = true
local menuIndex, menuItemIndex = 1, 1
local menuOpen = false
local helpPage
local undoState
local status = "Welcome! Draw a card or select a tableau card."

local menus = {
  { name = "Game", items = {
    { "New Game", "newGame" }, { "Undo Move", "undo" }, { "Exit", "quit" },
  } },
  { name = "Help", items = {
    { "How to Play", "rules" }, { "Keyboard Help", "keyboardHelp" },
  } },
}

local function rankName(rank)
  if rank == 1 then return "A" end
  if rank == 11 then return "J" end
  if rank == 12 then return "Q" end
  if rank == 13 then return "K" end
  return tostring(rank)
end

local function isRed(card)
  return card.suit == "H" or card.suit == "D"
end

local function copyCards(cards)
  local copy = {}
  for i, card in ipairs(cards) do
    copy[i] = { rank = card.rank, suit = card.suit, faceUp = card.faceUp }
  end
  return copy
end

local function saveUndo()
  local previousTableau, previousFoundations = {}, {}
  for i = 1, 7 do previousTableau[i] = copyCards(tableau[i]) end
  for i = 1, 4 do previousFoundations[i] = copyCards(foundations[i]) end
  undoState = {
    stock = copyCards(stock),
    waste = copyCards(waste),
    foundations = previousFoundations,
    tableau = previousTableau,
    focusColumn = focusColumn,
    focusCard = focusCard,
  }
end

local function undoMove()
  if not undoState then
    status = "Nothing to undo."
    return
  end
  stock, waste = undoState.stock, undoState.waste
  foundations, tableau = undoState.foundations, undoState.tableau
  focusColumn, focusCard = undoState.focusColumn, undoState.focusCard
  undoState = nil
  selection = nil
  status = "Move undone. No redo is available."
end

local function newGame()
  local deck = {}
  for _, suit in ipairs(SUITS) do
    for rank = 1, 13 do
      deck[#deck + 1] = { rank = rank, suit = suit, faceUp = false }
    end
  end

  local seed = os.epoch and os.epoch("utc") or math.floor(os.clock() * 1000000)
  math.randomseed(seed % 2147483647)
  for i = #deck, 2, -1 do
    local j = math.random(i)
    deck[i], deck[j] = deck[j], deck[i]
  end

  stock, waste = {}, {}
  foundations = { {}, {}, {}, {} }
  tableau = { {}, {}, {}, {}, {}, {}, {} }
  selection = nil
  focusColumn, focusCard = 1, 1
  tableauTop = { 1, 1, 1, 1, 1, 1, 1 }
  undoState = nil

  for column = 1, 7 do
    for row = 1, column do
      local card = table.remove(deck)
      card.faceUp = row == column
      tableau[column][#tableau[column] + 1] = card
    end
  end
  for i = 1, #deck do stock[#stock + 1] = deck[i] end
  status = "New game. Build down in alternating colours; build foundations up by suit."
end

local function drawStock()
  if #stock == 0 and #waste == 0 then
    selection = nil
    status = "There are no cards left in the stock."
    return
  end
  saveUndo()
  selection = nil
  if #stock > 0 then
    local card = table.remove(stock)
    card.faceUp = true
    waste[#waste + 1] = card
    status = "Drew " .. rankName(card.rank) .. card.suit .. "."
  elseif #waste > 0 then
    for i = #waste, 1, -1 do
      local card = table.remove(waste)
      card.faceUp = false
      stock[#stock + 1] = card
    end
    status = "Recycled the waste pile."
  end
end

local function selectCard(source, pile, index)
  local card
  if source == "tableau" then
    local cards = tableau[pile]
    card = cards and cards[index]
    if not card or not card.faceUp then
      status = "Select a face-up tableau card."
      return false
    end
  elseif source == "waste" then
    if pile ~= 1 then return false end
    card = waste[#waste]
  elseif source == "foundation" then
    local cards = foundations[pile]
    card = cards and cards[#cards]
  end
  if not card then
    status = "That pile has no card to select."
    return false
  end
  selection = { source = source, pile = pile, index = source == "tableau" and index or nil }
  status = "Selected " .. rankName(card.rank) .. card.suit .. ". Choose a destination."
  return true
end

local function selectedCard()
  if not selection then return nil end
  if selection.source == "tableau" then
    return tableau[selection.pile][selection.index]
  elseif selection.source == "waste" then
    return waste[#waste]
  end
  local cards = foundations[selection.pile]
  return cards[#cards]
end

local function removeSelection()
  local moved
  if selection.source == "tableau" then
    local cards = tableau[selection.pile]
    moved = {}
    while #cards >= selection.index do
      moved[#moved + 1] = table.remove(cards, selection.index)
    end
    if #cards > 0 and not cards[#cards].faceUp then
      cards[#cards].faceUp = true
    end
  elseif selection.source == "waste" then
    moved = { table.remove(waste) }
  else
    moved = { table.remove(foundations[selection.pile]) }
  end
  selection = nil
  return moved
end

local function tryMoveToTableau(destination)
  if not selection then return false end
  if selection.source == "tableau" and selection.pile == destination then
    return false
  end

  local card = selectedCard()
  if not card then return false end
  local target = tableau[destination]
  local top = target[#target]
  local legal = top and (top.faceUp and isRed(top) ~= isRed(card) and top.rank == card.rank + 1)
    or (not top and card.rank == 13)
  if not legal then
    status = "Invalid move: place a King on an empty column, or alternate colours downward."
    return false
  end

  saveUndo()
  local moved = removeSelection()
  for i = 1, #moved do target[#target + 1] = moved[i] end
  focusColumn, focusCard = destination, #target
  status = "Moved " .. rankName(card.rank) .. card.suit .. " to column " .. destination .. "."
  return true
end

local function tryMoveToFoundation(destination)
  if not selection then return false end
  local card = selectedCard()
  if not card then return false end
  if selection.source == "tableau" and selection.index ~= #tableau[selection.pile] then
    status = "Only a single card can be moved to a foundation."
    return false
  end
  if selection.source == "foundation" then
    status = "That card is already in a foundation."
    return false
  end
  if SUITS[destination] ~= card.suit then
    status = "Foundations must match the card's suit."
    return false
  end

  local target = foundations[destination]
  local top = target[#target]
  if (top and card.rank ~= top.rank + 1) or (not top and card.rank ~= 1) then
    status = "Foundations start with an Ace and build up by suit."
    return false
  end
  saveUndo()
  removeSelection()
  target[#target + 1] = card
  status = "Moved " .. rankName(card.rank) .. card.suit .. " to its foundation."

  local won = true
  for i = 1, #foundations do
    if #foundations[i] ~= 13 then won = false break end
  end
  if won then status = "You win! Press N or click 'New Game' to play again." end
  return true
end

local function autoFoundation()
  if selection then
    local card = selectedCard()
    if card then
      for i, suit in ipairs(SUITS) do
        if suit == card.suit then
          tryMoveToFoundation(i)
          return
        end
      end
    end
    return
  end
  if #waste > 0 and selectCard("waste", 1) then
    local card = selectedCard()
    for i, suit in ipairs(SUITS) do
      if suit == card.suit then
        if tryMoveToFoundation(i) then return end
        break
      end
    end
    selection = nil
  end
  for column = 1, 7 do
    local cards = tableau[column]
    if #cards > 0 and cards[#cards].faceUp and selectCard("tableau", column, #cards) then
      local card = selectedCard()
      for i, suit in ipairs(SUITS) do
        if suit == card.suit then
          if tryMoveToFoundation(i) then return end
          break
        end
      end
      selection = nil
    end
  end
  status = "No exposed card can move to a foundation."
end

local function writeAt(x, y, text, foreground, background)
  local width, height = term.getSize()
  if y < 1 or y > height or x > width then return end
  if x < 1 then
    text = text:sub(2 - x)
    x = 1
  end
  text = text:sub(1, width - x + 1)
  term.setCursorPos(x, y)
  term.setTextColor(foreground)
  term.setBackgroundColor(background)
  term.write(text)
end

local function cardText(card)
  local value = rankName(card.rank) .. card.suit
  local inner = CARD_WIDTH - 2
  local left = math.floor((inner - #value) / 2)
  return "[" .. (" "):rep(left) .. value .. (" "):rep(inner - left - #value) .. "]"
end

local function drawCard(x, y, card, hidden, selected)
  if hidden then
    writeAt(x, y, "[####]", C.lightBlue, C.blue)
  elseif not card then
    writeAt(x, y, "[    ]", C.green, C.black)
  elseif selected then
    writeAt(x, y, cardText(card), isRed(card) and C.red or C.black, C.cyan)
  else
    writeAt(x, y, cardText(card), isRed(card) and C.red or C.black, C.white)
  end
end

local function columnStep(width)
  return math.max(1, math.floor((width - CARD_WIDTH) / 6))
end

local function foundationStart(width)
  return math.max(1, width - (4 * CARD_WIDTH + 3) + 1)
end

local function visibleTableauRows(height)
  return math.max(1, height - TABLEAU_Y - 3)
end

local function keepFocusedCardVisible()
  local _, height = term.getSize()
  local cards = tableau[focusColumn]
  local count = #cards
  local rows = visibleTableauRows(height)
  local maxStart = math.max(1, count - rows + 1)
  tableauTop[focusColumn] = math.max(1, math.min(tableauTop[focusColumn], maxStart))
  focusCard = math.max(1, math.min(focusCard, math.max(1, count)))
  if focusCard < tableauTop[focusColumn] then
    tableauTop[focusColumn] = focusCard
  elseif focusCard >= tableauTop[focusColumn] + rows then
    tableauTop[focusColumn] = focusCard - rows + 1
  end
  tableauTop[focusColumn] = math.max(1, math.min(tableauTop[focusColumn], maxStart))
end

local function scrollFocusedColumn(direction)
  local _, height = term.getSize()
  local cards = tableau[focusColumn]
  local count = #cards
  local rows = visibleTableauRows(height)
  local maxStart = math.max(1, count - rows + 1)
  local start = math.max(1, math.min(tableauTop[focusColumn], maxStart))
  local nextStart = math.max(1, math.min(start + direction * math.max(1, rows - 1), maxStart))
  if nextStart == start then
    status = direction < 0 and "Already at the top of this column." or "Already at the bottom of this column."
    return
  end
  tableauTop[focusColumn] = nextStart
  focusCard = math.max(nextStart, math.min(focusCard, math.max(1, math.min(count, nextStart + rows - 1))))
  status = ("Showing cards %d-%d in column %d."):format(
    nextStart, math.min(count, nextStart + rows - 1), focusColumn)
end

local function menuLayout(width)
  local starts, labels, position = {}, {}, 1
  for i = 1, #menus do
    labels[i] = " " .. menus[i].name .. " "
    position = position + #labels[i]
  end
  position = math.max(1, width - position + 1)
  for i = 1, #menus do
    starts[i] = position
    position = position + #labels[i] + 1
  end
  return starts, labels, 0
end

local function statusLines(text, width)
  local lines, line = {}, ""
  for word in tostring(text):gmatch("%S+") do
    if line == "" then
      line = word
    elseif #line + #word + 1 <= width then
      line = line .. " " .. word
    else
      lines[#lines + 1] = line
      line = word
    end
  end
  if line ~= "" then lines[#lines + 1] = line end
  if #lines > 2 then
    lines[2] = lines[2]:sub(1, math.max(1, width - 3)) .. "..."
  end
  return lines
end

local function drawHelp()
  if not helpPage then return end
  local width, height = term.getSize()
  local title = helpPage == "rules" and "How to Play" or "Keyboard Help"
  local entries
  if helpPage == "rules" then
    entries = {
      { "", "Move face-up cards down, alternating colours." },
      { "", "Only a King can fill an empty tableau column." },
      { "", "Build each foundation from Ace to King by suit." },
      { "", "Click the stock to draw; click again when empty to recycle the waste pile." },
      { "", "Use the bottom-right buttons to scroll a long column." },
      { "", "Select a card, then click a destination pile." },
      { "", "Right-click or press Escape to cancel selection." },
    }
  else
    entries = {
      { "Arrows", "Choose a tableau card or column" },
      { "Enter", "Select a card or move to its column" },
      { "1-7", "Select a card or destination column" },
      { "D", "Draw from stock or recycle waste" },
      { "W", "Select the top waste card" },
      { "A", "Try moving a card to its foundation" },
      { "F1-F4", "Select or move to a foundation" },
      { "PgUp/Dn", "Scroll the focused tableau column" },
      { "U", "Undo the last move (once; no redo)" },
      { "N", "Start a new game" },
      { "F10", "Open the top menus" },
      { "Esc/Q", "Cancel selection / exit" },
    }
  end

  local boxWidth = math.min(width, 60)
  local innerWidth = math.max(1, boxWidth - 4)
  local keyWidth = 0
  if helpPage == "keyboard" then
    for _, entry in ipairs(entries) do keyWidth = math.max(keyWidth, #entry[1]) end
    keyWidth = math.min(12, keyWidth)
  end
  local descriptionWidth = math.max(1, innerWidth - keyWidth - (keyWidth > 0 and 1 or 0))
  local lines = {}
  for _, entry in ipairs(entries) do
    local wrapped, line = {}, ""
    for word in entry[2]:gmatch("%S+") do
      if line == "" then
        line = word
      elseif #line + #word + 1 <= descriptionWidth then
        line = line .. " " .. word
      else
        wrapped[#wrapped + 1] = line
        line = word
      end
    end
    if line ~= "" then wrapped[#wrapped + 1] = line end
    for i, text in ipairs(wrapped) do
      local key = i == 1 and entry[1] or ""
      lines[#lines + 1] = keyWidth > 0
        and (key .. (" "):rep(math.max(1, keyWidth - #key + 1)) .. text)
        or text
    end
  end

  local boxHeight = math.min(height, #lines + 4)
  local left = math.max(1, math.floor((width - boxWidth) / 2) + 1)
  local top = math.max(1, math.floor((height - boxHeight) / 2) + 1)
  term.setBackgroundColor(C.grey)
  term.setTextColor(C.white)
  for y = top, top + boxHeight - 1 do
    term.setCursorPos(left, y)
    term.write((" "):rep(boxWidth))
  end
  term.setCursorPos(left, top)
  term.write(("+" .. ("-"):rep(math.max(0, boxWidth - 2)) .. "+"):sub(1, boxWidth))
  if boxHeight > 2 then
    term.setCursorPos(left + 2, top + 1)
    term.write(title:sub(1, math.max(0, boxWidth - 4)))
  end
  for i = 1, math.min(#lines, boxHeight - 4) do
    term.setCursorPos(left + 2, top + 1 + i)
    term.write(lines[i]:sub(1, innerWidth))
  end
  term.setCursorPos(left, top + boxHeight - 1)
  term.write(("+" .. ("-"):rep(math.max(0, boxWidth - 2)) .. "+"):sub(1, boxWidth))
  if boxHeight >= 4 then
    term.setCursorPos(left + 2, top + boxHeight - 2)
    term.write(("Press any key or click to close"):sub(1, innerWidth))
  end
end

local function showSplash()
  local width, height = term.getSize()
  local splash = {
    { "KLONDIKE SOLITAIRE", C.lime },
    { "================================", C.grey },
    { "", C.white },
    { "Version 1.0", C.lightGrey },
    { "Copyright (C) 2026", C.lightGrey },
    { "Hex Development Not-So-Team", C.lightGrey },
    { "", C.white },
    { "Click or press any key to play", C.yellow },
  }
  local top = math.max(1, math.floor((height - #splash) / 2) + 1)

  term.setBackgroundColor(C.black)
  term.setTextColor(C.white)
  term.clear()
  for i, item in ipairs(splash) do
    local y = top + i - 1
    if y <= height then
      local text, foreground = item[1], item[2]
      writeAt(math.max(1, math.floor((width - #text) / 2) + 1), y, text, foreground, C.black)
    end
  end
  term.setCursorPos(1, 1)

  while true do
    local event = os.pullEvent()
    if event == "key" or event == "mouse_click" then return end
  end
end

local function draw()
  local width, height = term.getSize()
  local step = columnStep(width)
  local rows = visibleTableauRows(height)
  keepFocusedCardVisible()
  term.setBackgroundColor(C.black)
  term.setTextColor(C.white)
  term.clear()

  writeAt(1, 1, "KLONDIKE", C.lime, C.black)
  local starts, labels, scroll = menuLayout(width)
  for i = 1, #menus do
    local x = starts[i] - scroll
    local first = math.max(1, 2 - x)
    local last = math.min(#labels[i], width - x + 1)
    if first <= last then
      if menuOpen and i == menuIndex then
        writeAt(math.max(1, x), 1, labels[i]:sub(first, last), C.white, C.blue)
      elseif i == menuIndex then
        writeAt(math.max(1, x), 1, labels[i]:sub(first, last), C.black, C.cyan)
      else
        writeAt(math.max(1, x), 1, labels[i]:sub(first, last), C.white, C.grey)
      end
    end
  end
  writeAt(1, 3, "STOCK", C.lightGrey, C.black)
  writeAt(step + 1, 3, "WASTE", C.lightGrey, C.black)
  local baseX = foundationStart(width)
  writeAt(baseX, 3, "FOUNDATIONS", C.lightGrey, C.black)

  if #stock > 0 then
    drawCard(1, 4, nil, true, false)
  elseif #waste > 0 then
    writeAt(1, 4, "[RCL ]", C.green, C.black)
  else
    drawCard(1, 4, nil, false, false)
  end
  drawCard(step + 1, 4, waste[#waste], false, selection and selection.source == "waste")
  for i = 1, 4 do
    local cards = foundations[i]
    local x = baseX + (i - 1) * (CARD_WIDTH + 1)
    if cards[#cards] then
      drawCard(x, 4, cards[#cards], false,
        selection and selection.source == "foundation" and selection.pile == i)
    else
      writeAt(x, 4, "[ " .. SUITS[i] .. "  ]", C.lightGrey, C.black)
    end
  end

  for column = 1, 7 do
    local cards = tableau[column]
    local maxStart = math.max(1, #cards - rows + 1)
    local start = math.max(1, math.min(tableauTop[column], maxStart))
    tableauTop[column] = start
    local x = 2 + (column - 1) * step
    writeAt(x, 5, tostring(column), column == focusColumn and C.yellow or C.lightGrey, C.black)
    for row = 0, rows - 1 do
      local index = start + row
      if index <= #cards then
        local card = cards[index]
        local chosen = selection and selection.source == "tableau"
          and selection.pile == column and index >= selection.index
        drawCard(x, TABLEAU_Y + row, card, not card.faceUp, chosen)
      elseif #cards == 0 and row == 0 then
        drawCard(x, TABLEAU_Y, nil, false, false)
      end
    end
    if column == focusColumn then
      local focusY = TABLEAU_Y + focusCard - start
      if focusY >= TABLEAU_Y and focusY < TABLEAU_Y + rows then
        writeAt(math.max(1, x - 1), focusY, ">", C.yellow, C.black)
      end
    end
  end

  local lines = statusLines(status, math.max(1, width - 9))
  if height >= 2 then
    writeAt(1, height - 1, lines[1] or "", C.white, C.black)
    writeAt(1, height, lines[2] or "", C.white, C.black)
    writeAt(width - 3, height - 1, "[UP]", C.white, C.blue)
    writeAt(width - 3, height, "[DN]", C.white, C.blue)
  end

  if menuOpen then
    local items = menus[menuIndex].items
    local popupWidth = 12
    for i = 1, #items do popupWidth = math.max(popupWidth, #items[i][1] + 2) end
    popupWidth = math.min(popupWidth, width)
    local popupX = math.max(1, math.min(starts[menuIndex] - scroll, width - popupWidth + 1))
    for i = 1, math.min(#items, math.max(0, height - 3)) do
      writeAt(popupX, i + 1, (" " .. items[i][1] .. (" "):rep(popupWidth)):sub(1, popupWidth),
        i == menuItemIndex and C.white or C.black, i == menuItemIndex and C.blue or C.grey)
    end
  end
  drawHelp()
  term.setCursorPos(1, 1)
end

local function clickTableau(x, y)
  local width, height = term.getSize()
  local step = columnStep(width)
  local rows = visibleTableauRows(height)
  if y < TABLEAU_Y or y >= TABLEAU_Y + rows then return false end

  local column = math.floor((x - 2) / step) + 1
  if column < 1 or column > 7 then return false end
  local cards = tableau[column]
  local maxStart = math.max(1, #cards - rows + 1)
  local start = math.max(1, math.min(tableauTop[column], maxStart))
  local index = start + y - TABLEAU_Y
  focusColumn = column
  if index <= #cards then
    focusCard = index
    if selection and not (selection.source == "tableau" and selection.pile == column) then
      tryMoveToTableau(column)
      return true
    end
    selectCard("tableau", column, index)
  else
    focusCard = math.max(1, #cards)
    if selection then
      tryMoveToTableau(column)
    else
      status = "Select a card first; only a King can fill an empty column."
    end
  end
  return true
end

local function activateMenuItem(action)
  menuOpen = false
  if action == "newGame" then
    newGame()
  elseif action == "undo" then
    undoMove()
  elseif action == "quit" then
    running = false
  elseif action == "rules" then
    helpPage = "rules"
  elseif action == "keyboardHelp" then
    helpPage = "keyboard"
  end
end

local function handleClick(button, x, y)
  if button == 2 then
    selection = nil
    status = "Selection cleared."
    return
  elseif button ~= 1 then
    return
  end
  if helpPage then
    helpPage = nil
    return
  end

  local width = term.getSize()
  local _, height = term.getSize()
  if x >= width - 3 and y == height - 1 then
    scrollFocusedColumn(-1)
    return
  elseif x >= width - 3 and y == height then
    scrollFocusedColumn(1)
    return
  end

  local starts, labels, scroll = menuLayout(width)
  if y == 1 then
    for i = 1, #menus do
      local left = starts[i] - scroll
      if x >= left and x < left + #labels[i] then
        if menuOpen and menuIndex == i then
          menuOpen = false
        else
          menuIndex, menuItemIndex, menuOpen = i, 1, true
        end
        return
      end
    end
    menuOpen = false
  elseif menuOpen then
    local items = menus[menuIndex].items
    local popupWidth = 12
    for i = 1, #items do popupWidth = math.max(popupWidth, #items[i][1] + 2) end
    popupWidth = math.min(popupWidth, width)
    local popupX = math.max(1, math.min(starts[menuIndex] - scroll, width - popupWidth + 1))
    if x >= popupX and x < popupX + popupWidth and y >= 2 and y <= #items + 1 then
      activateMenuItem(items[y - 1][2])
      return
    end
    menuOpen = false
  end

  if y == 4 then
    local step = columnStep(width)
    if x >= 1 and x <= CARD_WIDTH then
      drawStock()
      return
    elseif x >= step + 1 and x <= step + CARD_WIDTH then
      if #waste > 0 then selectCard("waste", 1) end
      return
    end
    local baseX = foundationStart(width)
    for i = 1, 4 do
      local left = baseX + (i - 1) * (CARD_WIDTH + 1)
      if x >= left and x < left + CARD_WIDTH then
        if selection then
          tryMoveToFoundation(i)
        else
          selectCard("foundation", i)
        end
        return
      end
    end
  end
  clickTableau(x, y)
end

newGame()
showSplash()
while running do
  draw()
  local event, a, b, c = os.pullEvent()
  if event == "mouse_click" then
    handleClick(a, b, c)
  elseif event == "key" then
    if helpPage then
      helpPage = nil
    elseif menuOpen then
      local items = menus[menuIndex].items
      if a == keys.escape or a == keys.f10 then
        menuOpen = false
      elseif a == keys.up then
        menuItemIndex = (menuItemIndex - 2) % #items + 1
      elseif a == keys.down then
        menuItemIndex = menuItemIndex % #items + 1
      elseif a == keys.left or a == keys.right then
        menuIndex = menuIndex == 1 and 2 or 1
        menuItemIndex = 1
      elseif a == keys.enter then
        activateMenuItem(items[menuItemIndex][2])
      end
    elseif a == keys.f10 then
      menuOpen = true
      menuItemIndex = 1
    elseif a == keys.escape then
      selection = nil
      status = "Selection cleared."
    elseif a == keys.left then
      focusColumn = math.max(1, focusColumn - 1)
      focusCard = math.max(1, math.min(#tableau[focusColumn], focusCard))
    elseif a == keys.right then
      focusColumn = math.min(7, focusColumn + 1)
      focusCard = math.max(1, math.min(#tableau[focusColumn], focusCard))
    elseif a == keys.up then
      local firstFaceUp = 1
      while firstFaceUp <= #tableau[focusColumn] and not tableau[focusColumn][firstFaceUp].faceUp do
        firstFaceUp = firstFaceUp + 1
      end
      focusCard = math.max(firstFaceUp, focusCard - 1)
    elseif a == keys.down then
      focusCard = math.max(1, math.min(#tableau[focusColumn], focusCard + 1))
    elseif a == keys.pageUp then
      scrollFocusedColumn(-1)
    elseif a == keys.pageDown then
      scrollFocusedColumn(1)
    elseif a == keys.enter or a == keys.space then
      if selection then
        tryMoveToTableau(focusColumn)
      elseif #tableau[focusColumn] > 0 then
        selectCard("tableau", focusColumn, focusCard)
      else
        status = "That column is empty."
      end
    elseif a == keys.f1 or a == keys.f2 or a == keys.f3 or a == keys.f4 then
      local foundation = a - keys.f1 + 1
      if selection then
        tryMoveToFoundation(foundation)
      else
        selectCard("foundation", foundation)
      end
    elseif a == keys.d then
      drawStock()
    elseif a == keys.w then
      selectCard("waste", 1)
    elseif a == keys.a then
      autoFoundation()
    elseif a == keys.n then
      newGame()
    elseif a == keys.u then
      undoMove()
    elseif a == keys.q then
      running = false
    end
  elseif event == "char" then
    local column = tonumber(a)
    if column and column >= 1 and column <= 7 then
      if selection then
        tryMoveToTableau(column)
      else
        focusColumn = column
        focusCard = math.max(1, #tableau[column])
        if focusCard > 0 then selectCard("tableau", column, focusCard) end
      end
    end
  end
end

term.setBackgroundColor(C.black)
term.setTextColor(C.white)
term.clear()
term.setCursorPos(1, 1)